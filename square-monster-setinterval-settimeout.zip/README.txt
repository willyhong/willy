A Pen created at CodePen.io. You can find this one at https://codepen.io/HONG0117/pen/rqyvOw.

 